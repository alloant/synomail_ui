#!/bin/python
# -*- coding: utf-8 -*-

from synomail_ui.mainWindow import main

main()
